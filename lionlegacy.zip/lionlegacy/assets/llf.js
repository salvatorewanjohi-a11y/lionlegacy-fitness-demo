( function () {
	const cfg = window.LLF || {};
	const freeAt = Number( cfg.freeAt ) || 10000;
	const fmt = ( n ) => 'KSh ' + Math.round( n ).toLocaleString( 'en-KE' );
	const $$ = ( sel, root = document ) => Array.from( root.querySelectorAll( sel ) );
	const esc = ( s ) => String( s ).replace( /[&<>"']/g, ( c ) => ( { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' } )[ c ] );
	// Store API names come HTML-encoded (e.g. &#8243;); turn them back into plain text.
	const plain = ( s ) => new DOMParser().parseFromString( String( s ), 'text/html' ).documentElement.textContent;
	const money = ( minor, prices ) => Number( minor ) / Math.pow( 10, ( prices && prices.currency_minor_unit ) || 0 );
	const heart = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 20.3 4.6 13a4.8 4.8 0 0 1 6.8-6.8l.6.6.6-.6a4.8 4.8 0 0 1 6.8 6.8Z"/></svg>';
	// Products with flavours, designs or sizes are chosen on the product page.
	const hasOptions = ( p ) => p.type !== 'simple' || p.has_options;

	/* Toasts ------------------------------------------------------------ */
	function toast( msg ) {
		let box = document.querySelector( '.llf-toasts' );
		if ( ! box ) {
			box = document.createElement( 'div' );
			box.className = 'llf-toasts';
			box.setAttribute( 'role', 'status' );
			box.setAttribute( 'aria-live', 'polite' );
			document.body.appendChild( box );
		}
		const t = document.createElement( 'div' );
		t.className = 'llf-toast';
		t.innerHTML = msg;
		box.appendChild( t );
		setTimeout( () => t.classList.add( 'is-out' ), 3200 );
		setTimeout( () => t.remove(), 3700 );
	}
	document.body.addEventListener( 'wc-blocks_added_to_cart', () => toast( '✓ Added to your cart' ) );
	if ( window.jQuery ) window.jQuery( document.body ).on( 'added_to_cart', () => toast( '✓ Added to your cart' ) );

	/* Store API ---------------------------------------------------------- */
	let nonce = '';
	async function getCart() {
		const res = await fetch( cfg.store + 'cart', { credentials: 'same-origin' } );
		nonce = res.headers.get( 'Nonce' ) || nonce;
		return res.json();
	}
	// The header mini cart keeps its own copy of the cart (Interactivity API, or wp.data on
	// older WooCommerce); tell whichever is on the page to reload it.
	async function refreshMiniCart( cart ) {
		try {
			const { store } = await import( '@wordpress/interactivity' );
			const wc = store( 'woocommerce' );
			if ( wc && wc.actions && wc.actions.refreshCartItems ) await wc.actions.refreshCartItems();
		} catch ( e ) {}
		const data = window.wp && window.wp.data;
		if ( cart && data && data.dispatch( 'wc/store/cart' ) && data.dispatch( 'wc/store/cart' ).receiveCart ) {
			data.dispatch( 'wc/store/cart' ).receiveCart( cart );
		}
	}
	async function syncBar() {
		try {
			const cart = await getCart();
			renderBar( money( cart.totals.total_items, cart.totals ) );
		} catch ( e ) {}
	}
	document.body.addEventListener( 'wc-blocks_removed_from_cart', syncBar );
	document.body.addEventListener( 'wc-blocks_added_to_cart', () => setTimeout( syncBar, 400 ) );
	// Quantity buttons and remove links inside the mini cart drawer.
	document.addEventListener( 'click', ( e ) => {
		if ( e.target.closest( '.wc-block-mini-cart__drawer button, .wc-block-mini-cart__drawer a' ) && ! e.target.closest( '[data-llf-wa-cart]' ) ) setTimeout( syncBar, 900 );
	} );

	// Adds one product or a whole stack (several ids), then updates the mini cart once.
	async function addToCart( ids, btn ) {
		ids = [].concat( ids ).map( Number ).filter( Boolean );
		if ( btn ) btn.disabled = true;
		try {
			if ( ! nonce ) await getCart();
			let cart;
			if ( ids.length === 1 ) {
				const res = await fetch( cfg.store + 'cart/add-item', {
					method: 'POST',
					credentials: 'same-origin',
					headers: { 'Content-Type': 'application/json', Nonce: nonce },
					body: JSON.stringify( { id: ids[ 0 ], quantity: 1 } ),
				} );
				cart = await res.json();
				if ( ! res.ok ) throw new Error( cart.message || 'Could not add' );
			} else {
				// A whole stack goes in one batch request, then the cart is read once.
				if ( btn ) btn.dataset.label = btn.textContent;
				if ( btn ) btn.textContent = 'Adding ' + ids.length + ' products…';
				const res = await fetch( cfg.store + 'batch', {
					method: 'POST',
					credentials: 'same-origin',
					headers: { 'Content-Type': 'application/json', Nonce: nonce },
					body: JSON.stringify( { requests: ids.map( ( id ) => ( { path: '/wc/store/v1/cart/add-item', method: 'POST', body: { id, quantity: 1 }, headers: { Nonce: nonce } } ) ) } ),
				} );
				const out = await res.json();
				const failed = ( out.responses || [] ).find( ( r ) => r.status >= 400 );
				if ( ! res.ok || failed ) throw new Error( ( failed && failed.body && failed.body.message ) || out.message || 'Could not add' );
				cart = await getCart();
				toast( '✓ ' + ids.length + ' products added to your cart' );
			}
			await refreshMiniCart( cart );
			// The mini cart opens its drawer on this event; our toast listens too.
			document.body.dispatchEvent( new CustomEvent( 'wc-blocks_added_to_cart', { bubbles: true } ) );
			// The drawer can briefly re-show an older copy while it opens; refresh once more after.
			setTimeout( () => refreshMiniCart(), 900 );
			renderBar( money( cart.totals.total_items, cart.totals ) );
		} catch ( e ) {
			toast( esc( plain( e.message || 'Could not add to cart. Please try again.' ) ) );
		} finally {
			if ( btn ) btn.disabled = false;
			if ( btn && btn.dataset.label ) btn.textContent = btn.dataset.label;
		}
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-llf-add], [data-llf-add-many]' );
		if ( ! b ) return;
		e.preventDefault();
		addToCart( ( b.dataset.llfAdd || b.dataset.llfAddMany ).split( ',' ), b );
	} );

	/* WhatsApp checkout -------------------------------------------------- */
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-llf-wa-cart]' );
		if ( ! b ) return;
		e.preventDefault();
		// Open the tab now (inside the click) so pop-up blockers allow it, then fill in the link.
		const win = window.open( '', '_blank' );
		try {
			const cart = await getCart();
			if ( ! cart.items || ! cart.items.length ) {
				if ( win ) win.close();
				toast( 'Your cart is empty.' );
				return;
			}
			const lines = [ 'Hi Lionlegacy Fitness, I\'d like to order:' ];
			cart.items.forEach( ( it ) => {
				// Chosen flavour, design or size.
				const picks = ( it.variation || [] ).map( ( v ) => v.value ).concat( ( it.item_data || [] ).map( ( d ) => plain( d.value ) ) );
				lines.push( '• ' + it.quantity + ' × ' + plain( it.name ) + ( picks.length ? ' (' + picks.join( ', ' ) + ')' : '' ) + ' – ' + fmt( money( it.totals.line_total, it.totals ) ) );
			} );
			( cart.coupons || [] ).forEach( ( c ) => lines.push( 'Promo code: ' + c.code.toUpperCase() ) );
			lines.push( 'Subtotal: ' + fmt( money( cart.totals.total_items, cart.totals ) - money( cart.totals.total_discount, cart.totals ) ) + ' (plus delivery)' );
			lines.push( 'Delivery to: ' );
			const url = 'https://wa.me/' + cfg.wa + '?text=' + encodeURIComponent( lines.join( '\n' ) );
			if ( win ) win.location = url;
			else window.location = url;
		} catch ( err ) {
			if ( win ) win.close();
			toast( 'Could not read your cart. Please try again.' );
		}
	} );

	/* Wishlist ---------------------------------------------------------- */
	const KEY = 'llf-wishlist';
	const readWish = () => {
		try {
			return JSON.parse( localStorage.getItem( KEY ) || '[]' ).map( Number ).filter( Boolean );
		} catch ( e ) {
			return [];
		}
	};
	const writeWish = ( ids ) => {
		try {
			localStorage.setItem( KEY, JSON.stringify( ids ) );
		} catch ( e ) {}
	};
	function paintWish() {
		const ids = readWish();
		// Only touch the DOM when something changed: the MutationObserver below calls this.
		$$( '[data-llf-wish]' ).forEach( ( b ) => {
			const on = ids.includes( Number( b.dataset.llfWish ) );
			if ( b.classList.contains( 'is-on' ) === on ) return;
			b.classList.toggle( 'is-on', on );
			b.setAttribute( 'aria-pressed', on ? 'true' : 'false' );
		} );
		$$( '[data-llf-wish-count]' ).forEach( ( el ) => {
			if ( el.textContent !== String( ids.length ) ) el.textContent = ids.length;
			el.hidden = ids.length === 0;
		} );
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-llf-wish]' );
		if ( ! b ) return;
		e.preventDefault();
		e.stopPropagation();
		const id = Number( b.dataset.llfWish );
		let ids = readWish();
		const on = ids.includes( id );
		ids = on ? ids.filter( ( x ) => x !== id ) : [ ...ids, id ];
		writeWish( ids );
		paintWish();
		toast( on ? 'Removed from your wishlist' : '♥ Saved to your <a href="' + esc( cfg.home || '/' ) + 'wishlist/">wishlist</a>' );
		if ( b.closest( '[data-llf-wishlist]' ) ) renderWishlist();
	} );

	const buyButton = ( p ) => {
		if ( ! p.is_in_stock ) return '<span class="llf-badge llf-badge--out">Out of stock</span>';
		return hasOptions( p )
			? '<a class="wp-element-button" href="' + esc( p.permalink ) + '">Choose options</a>'
			: '<button type="button" class="wp-element-button" data-llf-add="' + p.id + '">Add to cart</button>';
	};

	async function renderWishlist() {
		const box = document.querySelector( '[data-llf-wishlist]' );
		if ( ! box ) return;
		const ids = readWish();
		if ( ! ids.length ) {
			box.innerHTML = '<div class="llf-empty"><p>Your wishlist is empty. Tap the ♥ on any product to save it here.</p><a class="wp-element-button" href="' + esc( cfg.shop || '/shop/' ) + '">Browse the shop</a></div>';
			return;
		}
		try {
			const res = await fetch( cfg.store + 'products?include=' + ids.join( ',' ) + '&per_page=50' );
			const items = await res.json();
			box.innerHTML = '<div class="llf-wish-grid">' + items.map( ( p ) => {
				const img = p.images && p.images[ 0 ] ? '<img src="' + esc( p.images[ 0 ].thumbnail || p.images[ 0 ].src ) + '" alt="" loading="lazy">' : '';
				return '<article class="llf-wish-card"><a href="' + esc( p.permalink ) + '">' + img + '</a>' +
					'<button type="button" class="llf-heart is-on" data-llf-wish="' + p.id + '" aria-label="Remove from wishlist" aria-pressed="true">' + heart + '</button>' +
					'<h3><a href="' + esc( p.permalink ) + '">' + p.name + '</a></h3><div class="llf-wish-price">' + p.price_html + '</div>' + buyButton( p ) + '</article>';
			} ).join( '' ) + '</div>';
		} catch ( e ) {
			box.innerHTML = '<p>Could not load your wishlist. Please refresh the page.</p>';
		}
	}

	/* Quick view --------------------------------------------------------- */
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-llf-qv]' );
		if ( ! b ) return;
		e.preventDefault();
		e.stopPropagation();
		const dlg = document.getElementById( 'llf-qv' );
		const body = dlg && dlg.querySelector( '[data-llf-qv-body]' );
		if ( ! body || ! dlg.showModal ) return;
		body.innerHTML = '<p class="llf-small">Loading…</p>';
		dlg.showModal();
		try {
			const p = await ( await fetch( cfg.store + 'products/' + b.dataset.llfQv ) ).json();
			const imgs = ( p.images || [] ).map( ( im, i ) => '<img src="' + esc( im.src ) + '" alt="' + esc( im.alt || p.name ) + '"' + ( i ? ' hidden' : '' ) + '>' ).join( '' );
			const thumbs = ( p.images || [] ).length > 1 ? '<div class="llf-qv__thumbs">' + p.images.map( ( im, i ) => '<button type="button" data-llf-qv-img="' + i + '"><img src="' + esc( im.thumbnail || im.src ) + '" alt=""></button>' ).join( '' ) + '</div>' : '';
			const cat = p.categories && p.categories[ 0 ] ? '<p class="llf-eyebrow">' + esc( p.categories[ 0 ].name ) + '</p>' : '';
			body.innerHTML = '<div class="llf-qv__grid"><div class="llf-qv__media"><div class="llf-qv__main">' + imgs + '</div>' + thumbs + '</div>' +
				'<div class="llf-qv__info">' + cat + '<h2>' + p.name + '</h2><div class="llf-qv__price">' + p.price_html + '</div>' +
				'<div class="llf-qv__desc">' + ( p.short_description || '' ) + '</div>' +
				'<div class="llf-qv__actions">' + buyButton( p ) +
				'<a class="llf-link" href="' + esc( p.permalink ) + '">Full details &amp; specs →</a></div></div></div>';
		} catch ( err ) {
			body.innerHTML = '<p>Could not load this product. Please try again.</p>';
		}
	} );
	document.addEventListener( 'click', ( e ) => {
		const t = e.target.closest( '[data-llf-qv-img]' );
		if ( ! t ) return;
		const main = t.closest( '.llf-qv__media' ).querySelectorAll( '.llf-qv__main img' );
		main.forEach( ( im, i ) => ( im.hidden = i !== Number( t.dataset.llfQvImg ) ) );
	} );
	document.addEventListener( 'click', ( e ) => {
		if ( e.target.matches( 'dialog.llf-dialog' ) ) e.target.close();
	} );

	/* Instant search ----------------------------------------------------- */
	function initSearch() {
		$$( '.llf-search input[type="search"]' ).forEach( ( input ) => {
			const form = input.closest( 'form' );
			const list = document.createElement( 'div' );
			list.className = 'llf-suggest';
			list.hidden = true;
			form.style.position = 'relative';
			form.appendChild( list );
			let timer;
			let seq = 0;
			input.setAttribute( 'autocomplete', 'off' );
			input.addEventListener( 'input', () => {
				clearTimeout( timer );
				const q = input.value.trim();
				if ( q.length < 2 ) {
					list.hidden = true;
					return;
				}
				timer = setTimeout( async () => {
					const mine = ++seq;
					try {
						const res = await fetch( cfg.store + 'products?search=' + encodeURIComponent( q ) + '&per_page=6' );
						const items = await res.json();
						if ( mine !== seq ) return;
						list.innerHTML = items.length
							? items.map( ( p ) => '<a href="' + esc( p.permalink ) + '">' + ( p.images[ 0 ] ? '<img src="' + esc( p.images[ 0 ].thumbnail ) + '" alt="">' : '' ) + '<span>' + p.name + '<small>' + p.price_html + '</small></span></a>' ).join( '' ) + '<button type="submit">See all results for “' + esc( q ) + '”</button>'
							: '<p>No products match “' + esc( q ) + '”. <a href="https://wa.me/' + esc( cfg.wa ) + '?text=' + encodeURIComponent( 'Hi Lionlegacy Fitness, do you have ' + q + '?' ) + '">Ask us on WhatsApp</a></p>';
						list.hidden = false;
					} catch ( e ) {}
				}, 180 );
			} );
			document.addEventListener( 'click', ( e ) => {
				if ( ! form.contains( e.target ) ) list.hidden = true;
			} );
			input.addEventListener( 'keydown', ( e ) => {
				if ( e.key === 'Escape' ) list.hidden = true;
			} );
		} );
	}

	/* Price slider ------------------------------------------------------- */
	function initPrice() {
		$$( '[data-llf-price]' ).forEach( ( form ) => {
			const [ lo, hi ] = $$( 'input[type="range"]', form );
			const out = form.querySelector( 'output' );
			const paint = ( moved ) => {
				// The two handles can't cross.
				if ( Number( lo.value ) > Number( hi.value ) ) {
					if ( moved === lo ) hi.value = lo.value;
					else lo.value = hi.value;
				}
				out.textContent = fmt( lo.value ) + ' – ' + fmt( hi.value );
			};
			lo.addEventListener( 'input', () => paint( lo ) );
			hi.addEventListener( 'input', () => paint( hi ) );
		} );
	}

	/* Flavour, design and size options as buttons ------------------------ */
	function initSwatches() {
		const jq = window.jQuery;
		if ( ! jq ) return;
		$$( 'form.variations_form table.variations select' ).forEach( ( sel ) => {
			const all = Array.from( sel.options ).filter( ( o ) => o.value ).map( ( o ) => ( { v: o.value, t: o.textContent } ) );
			const wrap = document.createElement( 'div' );
			wrap.className = 'llf-swatches';
			// WooCommerce removes the choices that don't exist with what is already picked.
			const paint = () => {
				const live = new Set( Array.from( sel.options ).filter( ( o ) => o.value && ! o.disabled ).map( ( o ) => o.value ) );
				wrap.innerHTML = all.map( ( o ) => '<button type="button" class="llf-swatch' + ( sel.value === o.v ? ' is-on' : '' ) + '" data-v="' + esc( o.v ) + '"' + ( live.has( o.v ) ? '' : ' disabled' ) + '>' + esc( o.t ) + '</button>' ).join( '' );
			};
			wrap.addEventListener( 'click', ( e ) => {
				const b = e.target.closest( '.llf-swatch' );
				if ( ! b || b.disabled ) return;
				sel.value = sel.value === b.dataset.v ? '' : b.dataset.v;
				jq( sel ).trigger( 'change' );
			} );
			sel.classList.add( 'llf-swatch-select' );
			sel.after( wrap );
			paint();
			jq( sel.form ).on( 'woocommerce_update_variation_values woocommerce_variation_has_changed reset_data', () => setTimeout( paint, 0 ) );
		} );
	}

	/* Free-delivery bar and promo codes ---------------------------------- */
	function renderBar( total ) {
		const left = Math.max( 0, freeAt - total );
		const pct = Math.min( 100, Math.round( ( total / freeAt ) * 100 ) );
		const msg = left > 0
			? 'Add <strong>' + fmt( left ) + '</strong> more for <strong>free Nairobi doorstep delivery</strong>'
			: "<strong>You've unlocked free Nairobi doorstep delivery!</strong>";
		$$( '[data-llf-freebar]' ).forEach( ( el ) => {
			el.innerHTML = msg + '<div class="llf-freebar__track"><div class="llf-freebar__fill" style="width:' + pct + '%"></div></div>';
		} );
	}
	function watchCart() {
		const data = window.wp && window.wp.data;
		if ( ! data || ! data.select( 'wc/store/cart' ) ) return;
		let last = null;
		let codes = null;
		data.subscribe( () => {
			const store = data.select( 'wc/store/cart' );
			const totals = store.getCartTotals();
			if ( totals && totals.total_items !== undefined ) {
				const sub = money( totals.total_items, totals );
				if ( sub !== last ) {
					last = sub;
					renderBar( sub );
				}
			}
			const now = ( store.getCartData().coupons || [] ).map( ( c ) => c.code );
			if ( codes !== null ) now.filter( ( c ) => ! codes.includes( c ) ).forEach( ( c ) => toast( '✓ Promo code <strong>' + esc( c.toUpperCase() ) + '</strong> applied' ) );
			if ( store.hasFinishedResolution && store.hasFinishedResolution( 'getCartData' ) ) codes = now;
		} );
	}

	/* Reviews carousel --------------------------------------------------- */
	function initCarousels() {
		$$( '[data-llf-carousel]' ).forEach( ( c ) => {
			const track = c.querySelector( '.llf-reviews__track' );
			const by = ( dir ) => track.scrollBy( { left: dir * track.clientWidth * 0.9, behavior: 'smooth' } );
			c.querySelector( '[data-llf-prev]' ).addEventListener( 'click', () => by( -1 ) );
			c.querySelector( '[data-llf-next]' ).addEventListener( 'click', () => by( 1 ) );
		} );
	}

	/* Stack builder ------------------------------------------------------ */
	// Each goal fills its slots in order; beginners get the first 3, intermediates 4, advanced 5.
	const RECIPES = {
		muscle: { title: 'Muscle building stack', goal: 'Build muscle', slots: [ [ 'Protein', [ 'whey', 'isolate' ] ], [ 'Creatine', [ 'creatine' ] ], [ 'Shaker', [ 'shaker' ] ], [ 'Recovery', [ 'eaa', 'aminotabs' ] ], [ 'Pre-workout', [ 'pre' ] ] ] },
		fatloss: { title: 'Lean shred stack', goal: 'Lose fat', slots: [ [ 'Lean protein', [ 'leanwhey', 'isolate' ] ], [ 'Fat burner', [ 'burner' ] ], [ 'L-Carnitine', [ 'carnitine' ] ], [ 'Shaker', [ 'shaker' ] ], [ 'Recovery', [ 'eaa', 'hydration' ] ] ] },
		strength: { title: 'Strength & power stack', goal: 'Increase strength', slots: [ [ 'Creatine', [ 'creatine' ] ], [ 'Pre-workout', [ 'pre' ] ], [ 'Protein', [ 'whey' ] ], [ 'Lifting gear', [ 'belt', 'straps', 'wraps' ] ], [ 'Recovery', [ 'hmb', 'eaa' ] ] ] },
		endurance: { title: 'Endurance & energy stack', goal: 'Endurance & energy', slots: [ [ 'Hydration', [ 'hydration' ] ], [ 'Amino energy', [ 'aminoenergy' ] ], [ 'Beta-alanine', [ 'betaalanine' ] ], [ 'Recovery protein', [ 'recoveryshake' ] ], [ 'Water bottle', [ 'bottle', 'shaker' ] ] ] },
	};
	const LEVELS = { beginner: [ 'Beginner', 3, 0.1 ], intermediate: [ 'Intermediate', 4, 0.5 ], advanced: [ 'Advanced', 5, 0.9 ] };

	// Keep the most important slots that fit the budget at their cheapest (earlier slots matter more),
	// then upgrade each kept slot towards the price point that suits the experience level.
	// Returns the stack, plus the slots that didn't fit so the shopper can see what to add next.
	function buildStack( products, goal, level, budget ) {
		const [ , count, q ] = LEVELS[ level ];
		const slots = RECIPES[ goal ].slots.slice( 0, count ).map( ( [ label, types ] ) => ( {
			label,
			options: products.filter( ( p ) => types.includes( p.type ) ).sort( ( a, b ) => a.price - b.price ),
		} ) ).filter( ( s ) => s.options.length );
		let keep = [];
		let bestScore = 0;
		for ( let mask = 1; mask < 1 << slots.length; mask++ ) {
			const set = slots.map( ( s, i ) => i ).filter( ( i ) => mask & ( 1 << i ) );
			const cost = set.reduce( ( t, i ) => t + slots[ i ].options[ 0 ].price, 0 );
			const score = set.reduce( ( t, i ) => t + ( 1 << ( slots.length - i ) ), 0 );
			if ( cost <= budget && score > bestScore ) {
				bestScore = score;
				keep = set;
			}
		}
		const picks = keep.map( ( i ) => slots[ i ].options[ 0 ] );
		const sum = () => picks.reduce( ( t, p ) => t + p.price, 0 );
		keep.forEach( ( slot, n ) => {
			const opts = slots[ slot ].options;
			const want = opts[ Math.round( q * ( opts.length - 1 ) ) ].price;
			const room = budget - ( sum() - picks[ n ].price );
			let best = picks[ n ];
			opts.forEach( ( o ) => {
				if ( o.price > room ) return;
				const d = Math.abs( o.price - want ) - Math.abs( best.price - want );
				if ( d < 0 || ( d === 0 && o.price > best.price ) ) best = o;
			} );
			picks[ n ] = best;
		} );
		return {
			items: keep.map( ( slot, n ) => ( { label: slots[ slot ].label, product: picks[ n ] } ) ),
			missing: slots.filter( ( s, i ) => ! keep.includes( i ) ).map( ( s ) => ( { label: s.label, product: s.options[ 0 ] } ) ),
		};
	}

	function initStack() {
		const root = document.querySelector( '[data-llf-stack]' );
		if ( ! root ) return;
		const data = JSON.parse( root.querySelector( '[data-llf-stack-data]' ).textContent );
		const state = { goal: '', level: '', budget: 0 };
		const steps = $$( '.llf-stack__steps li', root );
		const show = ( n ) => {
			$$( 'section[data-step]', root ).forEach( ( s ) => ( s.hidden = Number( s.dataset.step ) !== n ) );
			steps.forEach( ( li, i ) => {
				li.classList.toggle( 'is-on', i === n - 1 );
				li.classList.toggle( 'is-done', i < n - 1 );
			} );
			root.scrollIntoView( { behavior: 'smooth', block: 'start' } );
		};
		const result = () => {
			const recipe = RECIPES[ state.goal ];
			const { items, missing } = buildStack( data.products, state.goal, state.level, state.budget );
			const box = root.querySelector( '[data-llf-stack-result]' );
			const total = items.reduce( ( t, it ) => t + it.product.price, 0 );
			const summary = recipe.goal + ' · ' + LEVELS[ state.level ][ 0 ] + ' · budget ' + fmt( state.budget );
			if ( ! items.length ) {
				const cheapest = data.products.filter( ( p ) => recipe.slots[ 0 ][ 1 ].includes( p.type ) ).sort( ( a, b ) => a.price - b.price )[ 0 ];
				box.innerHTML = '<h2>Let\'s talk budget</h2><p>' + esc( summary ) + '. ' + ( cheapest ? 'The most affordable ' + esc( recipe.slots[ 0 ][ 0 ].toLowerCase() ) + ' we stock is <a href="' + esc( cheapest.url ) + '">' + esc( cheapest.name ) + '</a> at ' + fmt( cheapest.price ) + '.' : '' ) + ' Send us your goal on WhatsApp and we\'ll find the best start for your budget.</p>' +
					'<div class="llf-stack__actions"><a class="wp-element-button llf-wa-btn" target="_blank" rel="noopener" href="https://wa.me/' + esc( cfg.wa ) + '?text=' + encodeURIComponent( 'Hi Lionlegacy Fitness, I want to ' + recipe.goal.toLowerCase() + ' with a budget of ' + fmt( state.budget ) + '. What do you recommend?' ) + '">Ask us on WhatsApp</a><button type="button" class="llf-link" data-restart>Start again</button></div>';
				return;
			}
			const msg = [ 'Hi Lionlegacy Fitness, the stack builder suggested this ' + recipe.title.toLowerCase() + ' (' + summary + '):' ]
				.concat( items.map( ( it ) => '• ' + it.product.name + ' – ' + fmt( it.product.price ) ) )
				.concat( [ 'Total: ' + fmt( total ), 'Is it right for me?' ] ).join( '\n' );
			box.innerHTML = '<p class="llf-eyebrow">Your recommended stack</p><h2>' + esc( recipe.title ) + '</h2><p class="llf-small">' + esc( summary ) + '</p>' +
				'<ol class="llf-stack__list">' + items.map( ( it, n ) => {
					const p = it.product;
					const guide = data.guides[ p.type ];
					return '<li><span class="llf-stack__n">' + ( n + 1 ) + '</span>' + ( p.img ? '<a href="' + esc( p.url ) + '"><img src="' + esc( p.img ) + '" alt="" loading="lazy"></a>' : '' ) +
						'<div><p class="llf-stack__slot">' + esc( it.label ) + '</p><a class="llf-stack__name" href="' + esc( p.url ) + '">' + esc( p.name ) + '</a>' +
						( p.size ? '<span class="llf-stack__size">' + esc( p.size ) + '</span>' : '' ) +
						( guide ? '<p class="llf-stack__when"><strong>When:</strong> ' + esc( guide.when ) + '</p>' : '' ) + '</div><strong class="llf-stack__price">' + fmt( p.price ) + '</strong></li>';
				} ).join( '' ) + '</ol>' +
				'<div class="llf-stack__total"><span>Stack total</span><strong>' + fmt( total ) + '</strong><em>' + fmt( state.budget - total ) + ' left in your budget</em></div>' +
				( missing.length ? '<div class="llf-stack__next"><p><strong>Next on your list</strong> when your budget allows:</p>' + missing.map( ( m ) => '<p>' + esc( m.label ) + ': <a href="' + esc( m.product.url ) + '">' + esc( m.product.name ) + '</a> from ' + fmt( m.product.price ) + ' <button type="button" class="llf-set__add" data-llf-add="' + m.product.id + '">+ Add</button></p>' ).join( '' ) + '</div>' : '' ) +
				'<div class="llf-stack__actions"><button type="button" class="wp-element-button" data-llf-add-many="' + items.map( ( it ) => it.product.id ).join( ',' ) + '">Add full stack to cart</button>' +
				'<a class="wp-element-button llf-wa-btn" target="_blank" rel="noopener" href="https://wa.me/' + esc( cfg.wa ) + '?text=' + encodeURIComponent( msg ) + '">Check it with us on WhatsApp</a>' +
				'<button type="button" class="llf-link" data-restart>Start again</button></div>' +
				'<p class="llf-small">Suggestions are a starting point from what we have in stock. Follow the dosage on each label, and speak to your doctor first if you are under 18, pregnant or have a medical condition.</p>';
			toast( '✓ Your ' + esc( recipe.title.toLowerCase() ) + ' is ready' );
		};
		root.addEventListener( 'click', ( e ) => {
			const b = e.target.closest( 'button' );
			if ( ! b ) return;
			if ( b.dataset.goal ) {
				state.goal = b.dataset.goal;
				show( 2 );
			} else if ( b.dataset.level ) {
				state.level = b.dataset.level;
				show( 3 );
			} else if ( b.dataset.budget ) {
				state.budget = Number( b.dataset.budget );
				result();
				show( 4 );
			} else if ( b.hasAttribute( 'data-back' ) ) {
				show( Number( b.closest( 'section' ).dataset.step ) - 1 );
			} else if ( b.hasAttribute( 'data-restart' ) ) {
				show( 1 );
			}
		} );
		root.querySelector( '[data-own-budget]' ).addEventListener( 'submit', ( e ) => {
			e.preventDefault();
			state.budget = Math.max( 0, Number( e.target.querySelector( 'input' ).value ) || 0 );
			result();
			show( 4 );
		} );
	}

	function init() {
		initCarousels();
		initStack();
		paintWish();
		renderWishlist();
		initSearch();
		initPrice();
		initSwatches();
		watchCart();
		// Cards re-render client-side in some blocks; keep hearts in sync.
		new MutationObserver( () => paintWish() ).observe( document.body, { childList: true, subtree: true } );
	}
	if ( document.readyState === 'loading' ) document.addEventListener( 'DOMContentLoaded', init );
	else init();
} )();
