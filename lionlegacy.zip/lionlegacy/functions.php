<?php
/**
 * Lionlegacy Fitness child theme.
 */

const LLF_FREE_DELIVERY = 10000; // KSh, keep in step with the "Free Nairobi doorstep delivery" shipping method.
const LLF_WHATSAPP      = '254797623423';
const LLF_PHONE         = '+254 797 623 423';
const LLF_LOW_STOCK     = 2;
const LLF_FONTS         = 'https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@600;700;800&family=Inter:wght@400;500;600;700&display=swap';
const LLF_FILTERS       = [ 'goal' => 'Training goal' ];
const LLF_BUDGETS       = [ [ 'Under KSh 3,000', 0, 3000 ], [ 'KSh 3,000 – 6,000', 3000, 6000 ], [ 'KSh 6,000+', 6000, 0 ] ];

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_stylesheet_directory();
	$uri = get_stylesheet_directory_uri();
	wp_enqueue_style( 'llf-fonts', LLF_FONTS, [], null );
	wp_enqueue_style( 'llf', get_stylesheet_uri(), [], filemtime( $dir . '/style.css' ) );
	wp_enqueue_script( 'llf', $uri . '/assets/llf.js', [], filemtime( $dir . '/assets/llf.js' ), true );
	wp_localize_script( 'llf', 'LLF', [
		'freeAt' => LLF_FREE_DELIVERY,
		'store'  => esc_url_raw( rest_url( 'wc/store/v1/' ) ),
		'shop'   => esc_url_raw( wc_get_page_permalink( 'shop' ) ),
		'cart'   => esc_url_raw( wc_get_cart_url() ),
		'home'   => esc_url_raw( home_url( '/' ) ),
		'wa'     => LLF_WHATSAPP,
	] );
} );

add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_style( 'llf-fonts', LLF_FONTS, [], null );
} );
add_action( 'after_setup_theme', function () {
	add_editor_style( 'style.css' );
} );

function llf_wa_link( $text = '' ) {
	return 'https://wa.me/' . LLF_WHATSAPP . ( $text !== '' ? '?text=' . rawurlencode( $text ) : '' );
}

const LLF_WA_ICON = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm5.3 14.2c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.1-4.5-3.9-4.7-4.1-.1-.2-1.1-1.5-1.1-2.9s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.3 0 .5l-.4.6-.4.4c-.1.2-.3.3-.1.6.2.3.8 1.3 1.7 2.1 1.2 1 2.1 1.3 2.4 1.5.3.1.5.1.7-.1l.9-1.1c.2-.3.4-.2.7-.1l1.9.9c.3.1.5.2.5.3.1.2.1.7-.1 1.2Z"/></svg>';

/**
 * Specs as label => value pairs, from the "Label: value" lines staff type on the product screen.
 */
function llf_specs( $product_id ) {
	$out = [];
	foreach ( preg_split( '/\R/', (string) get_post_meta( $product_id, '_llf_specs', true ) ) as $line ) {
		$parts = array_map( 'trim', explode( ':', $line, 2 ) );
		if ( count( $parts ) === 2 && $parts[0] !== '' ) {
			$out[ $parts[0] ] = $parts[1];
		}
	}
	return $out;
}

/**
 * Usage guide per product type: [label, when, how, goes well with]. Staff pick the type on the product screen.
 * Gear types answer "use it for / how / pairs well with" instead of "when / how much / stack with".
 */
function llf_types() {
	return [
		'whey'          => [ 'Whey protein', 'Within an hour after training, or between meals to reach your daily protein.', 'One scoop in 200–300 ml of cold water or milk. Shake for 10–15 seconds.', 'Muscle gain: add creatine (3–5 g a day). Fat loss: switch to an isolate or diet whey.' ],
		'leanwhey'      => [ 'Lean whey protein', 'After training, or as a high-protein snack between meals.', 'One scoop in 200–300 ml of water for the fewest calories.', 'Fat loss: L-carnitine before cardio. Muscle gain: creatine every day.' ],
		'isolate'       => [ 'Protein isolate', 'Within an hour after training, or between meals.', 'One scoop in 200–300 ml of water or milk.', 'Lean muscle: creatine every day. Cutting: a fat burner and a calorie deficit.' ],
		'casein'        => [ 'Casein protein', '30–60 minutes before bed, or when you will go several hours without a meal.', 'One scoop in 250–300 ml of milk or water. It mixes thicker than whey.', 'A whey protein after training, for protein around the clock.' ],
		'recoveryshake' => [ 'Recovery protein', 'Straight after long runs, matches or hard sessions.', 'One serving in water, as on the label.', 'Electrolytes during the session and EAAs on long training days.' ],
		'gainer'        => [ 'Mass gainer', 'After training and between meals, on top of your normal meals, not instead of them.', 'Start with half a serving in milk for the first week, then build up to the full serving on the label.', 'Creatine (3–5 g a day) for strength and size.' ],
		'food'          => [ 'High-protein food', 'Breakfast, or as a snack between meals.', 'Prepare as on the label.', 'A protein shake after training.' ],
		'creatine'      => [ 'Creatine', 'Every day at any time, on training days and rest days. Taking it daily matters more than the timing.', '3–5 g (usually one scoop, or the serving on the label) in water, juice or your protein shake. No loading phase needed.', 'Muscle gain: whey protein. Strength: a pre-workout on heavy days. Drink plenty of water through the day.' ],
		'pre'           => [ 'Pre-workout', '20–30 minutes before training. If it contains caffeine, avoid it within about 6 hours of bedtime.', 'Start with half a scoop to see how you react, then use the label serving. Never take more than the label says.', 'Creatine for strength and EAAs during training. Don\'t combine it with fat burners or other stimulants.' ],
		'pump'          => [ 'Nitric oxide booster', '30–60 minutes before training.', 'Capsules with water, as on the label.', 'Creatine every day, or your usual pre-workout.' ],
		'drink'         => [ 'Energy drink', '20–30 minutes before training.', 'One chilled can. It contains caffeine, so don\'t mix it with other stimulants.', 'Creatine for strength and protein after training.' ],
		'burner'        => [ 'Fat burner', 'Morning and early afternoon, as on the label. Not late in the day if it contains stimulants.', 'Start with the lowest serving on the label for the first few days, with a full glass of water.', 'A diet whey or isolate to protect muscle, and L-carnitine before cardio. Don\'t combine it with pre-workouts or other stimulants.' ],
		'burnercaps'    => [ 'Weight-management support', 'With meals, as on the label.', 'Capsules or tablets with a full glass of water.', 'A calorie deficit, enough protein and regular training.' ],
		'carnitine'     => [ 'L-Carnitine', '30–60 minutes before training or cardio.', 'The serving on the label, with water.', 'A diet whey or isolate after training, and a fat burner if you are cutting.' ],
		'aminoenergy'   => [ 'Amino energy', 'Before or during training, or in the morning instead of coffee.', '1–2 scoops in water, as on the label. It contains caffeine.', 'Whey protein after training and creatine every day.' ],
		'eaa'           => [ 'Essential amino acids', 'During training, or between meals.', 'One scoop in 300–500 ml of water, sipped through your session.', 'Creatine every day and whey after training.' ],
		'hydration'     => [ 'Hydration & electrolytes', 'During long or hot sessions, and on match or race days.', 'One serving in about 500 ml of water, sipped while you train.', 'A recovery protein afterwards.' ],
		'aminotabs'     => [ 'Amino tablets', 'Around training and with meals.', 'The number of tablets on the label, with water.', 'Whey protein and creatine for muscle gain.' ],
		'hmb'           => [ 'HMB', 'Spread through the day with meals, as on the label.', 'Capsules with water.', 'Creatine and whey protein.' ],
		'betaalanine'   => [ 'Beta-alanine', 'Every day; many people take it before training.', 'The serving on the label in water. A harmless tingling feeling is normal.', 'Creatine for strength and a pre-workout for energy.' ],
		'multi'         => [ 'Multivitamin', 'Every day with a meal.', 'As on the label, usually one pack or serving with breakfast.', 'Fish oil and vitamin D3 for all-round health.' ],
		'vitamin'       => [ 'Vitamins & wellness', 'Every day with a meal.', 'As on the label.', 'A multivitamin for all-round cover.' ],
		'herbal'        => [ 'Herbal supplement', 'Every day with a meal.', 'As on the label.', 'A multivitamin and ZMB.' ],
		'sleep'         => [ 'Sleep support', '30–60 minutes before bed.', 'As on the label. Don\'t drive after taking it.', 'Casein before bed for overnight recovery.' ],
		'hormone'       => [ 'Testosterone & vitality support', 'Every day with meals, as on the label. For adults over 18.', 'Follow the label, including any on/off cycle it gives.', 'ZMB at night and a multivitamin.' ],
		'glucose'       => [ 'Glucose disposal support', 'Before your biggest carb meals of the day.', 'As on the label.', 'Creatine and a protein shake for muscle gain.' ],
		'calisthenics'  => [ 'Calisthenics equipment', 'Planche, L-sit, handstand, push-up and dip progressions, at home, in the park or at the gym.', 'Set them on flat, stable ground and warm up your wrists first.', 'Leather gloves for grip and a steel bottle to stay hydrated.' ],
		'belt'          => [ 'Lifting belt', 'Heavy squats, deadlifts and overhead presses.', 'Wear it snug around your waist and brace your core against it.', 'Lifting straps and wrist wraps.' ],
		'wraps'         => [ 'Wrist wraps', 'Heavy presses, push-ups and handstands.', 'Wrap firmly around the wrist joint, not the forearm.', 'A lifting belt and gloves.' ],
		'straps'        => [ 'Lifting straps', 'Heavy deadlifts, rows and shrugs.', 'Loop around the bar and twist to lock your grip.', 'A lifting belt.' ],
		'gloves'        => [ 'Gym gloves', 'Any session where your palms take a beating.', 'Pick Medium or Large; they should fit snugly.', 'Wrist wraps and lifting straps.' ],
		'sleeves'       => [ 'Knee sleeves', 'Squats, lunges and leg day.', 'Pull them on before your working sets; they should feel tight.', 'A lifting belt for heavy squats.' ],
		'bottle'        => [ 'Steel water bottle', 'All day, at the gym and on the go.', 'Hand wash only.', 'Electrolytes for long sessions.' ],
		'shaker'        => [ 'Shaker bottle', 'Protein shakes, creatine and pre-workout.', 'Liquid first, then powder. Rinse it straight after use.', 'Your protein and creatine.' ],
	];
}
const LLF_GEAR = [ 'calisthenics', 'belt', 'wraps', 'straps', 'gloves', 'sleeves', 'bottle', 'shaker' ];

function llf_type( $product_id ) {
	$type  = (string) get_post_meta( $product_id, '_llf_type', true );
	$types = llf_types();
	return isset( $types[ $type ] ) ? [ $type, $types[ $type ] ] : [ '', null ];
}

// Goal terms for a product, in the store's goal order.
function llf_product_goals( $product_id ) {
	$terms = wp_get_post_terms( $product_id, wc_attribute_taxonomy_name( 'goal' ) );
	if ( is_wp_error( $terms ) ) {
		return [];
	}
	usort( $terms, fn( $a, $b ) => (int) get_term_meta( $a->term_id, 'order', true ) <=> (int) get_term_meta( $b->term_id, 'order', true ) );
	return $terms;
}

/* -------------------------------------------------------------------------
 * Product page
 * ---------------------------------------------------------------------- */

// Goal tags and key specs above the add-to-cart button.
add_action( 'woocommerce_before_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$goals = llf_product_goals( $product->get_id() );
	if ( $goals ) {
		echo '<div class="llf-goal-tags">';
		foreach ( $goals as $t ) {
			echo '<a class="llf-badge llf-badge--goal" href="' . esc_url( add_query_arg( 'filter_goal', $t->slug, wc_get_page_permalink( 'shop' ) ) ) . '">' . esc_html( $t->name ) . '</a>';
		}
		echo '</div>';
	}
	$specs = array_slice( array_diff_key( llf_specs( $product->get_id() ), [ 'Best for' => 1, 'Lead time' => 1 ] ), 0, 4, true );
	if ( $specs ) {
		echo '<ul class="llf-keyspecs">';
		foreach ( $specs as $k => $v ) {
			echo '<li><span>' . esc_html( $k ) . '</span><strong>' . esc_html( $v ) . '</strong></li>';
		}
		echo '</ul>';
	}
	if ( get_post_meta( $product->get_id(), '_llf_made_to_order', true ) === 'yes' ) {
		echo '<p class="llf-mto"><strong>Made to order.</strong> We build and paint each one for you, usually in 3–5 days (dip bars 5–7 days). Tell us your colour in the order notes or on WhatsApp.</p>';
	}
} );

// Order on WhatsApp, the supplement advisor, guarantees and "frequently bought together" under the button.
add_action( 'woocommerce_after_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$price = $product->is_type( 'variable' ) ? 'from KSh ' . number_format( (float) $product->get_variation_price( 'min' ) ) : 'KSh ' . number_format( (float) $product->get_price() );
	$msg   = 'Hi Lionlegacy Fitness, is the ' . $product->get_name() . ' (' . $price . ') available? ' . $product->get_permalink();
	echo '<a class="llf-wa-order" href="' . esc_url( llf_wa_link( $msg ) ) . '" target="_blank" rel="noopener">' . LLF_WA_ICON . 'Order or ask about this on WhatsApp</a>';

	[ $type, $guide ] = llf_type( $product->get_id() );
	if ( $guide ) {
		$gear  = in_array( $type, LLF_GEAR, true );
		$heads = $gear ? [ 'Use it for', 'How', 'Pairs well with' ] : [ 'When to take', 'How much', 'Stack it with' ];
		echo '<div class="llf-advisor"><p class="llf-advisor__title">' . ( $gear ? 'Quick guide' : 'Supplement advisor' ) . ' <span>' . esc_html( $guide[0] ) . '</span></p><dl>';
		foreach ( $heads as $n => $h ) {
			echo '<div><dt>' . esc_html( $h ) . '</dt><dd>' . esc_html( $guide[ $n + 1 ] ) . '</dd></div>';
		}
		echo '</dl>';
		if ( ! $gear ) {
			echo '<p class="llf-advisor__ask">Not sure it fits your goal or budget? <a href="' . esc_url( llf_wa_link( 'Hi Lionlegacy Fitness, I need advice on the ' . $product->get_name() . '. My goal is: ' ) ) . '" target="_blank" rel="noopener">Ask us on WhatsApp</a> or <a href="' . esc_url( home_url( '/stack-builder/' ) ) . '">build your stack</a>.</p>';
		}
		echo '</div>';
	}

	echo '<div class="llf-guarantee"><div><span aria-hidden="true">✓</span><p><strong>Genuine, sealed products</strong>Check the seal, batch and expiry when it arrives, or see it in person at College House.</p></div><div><span aria-hidden="true">🦁</span><p><strong>Advice that fits your budget</strong>Tell us your goal and we\'ll tell you what to take and how.</p></div><div><span aria-hidden="true">🚚</span><p><strong>Delivered to your door</strong>Same-day riders in Nairobi, courier to any county, or free pickup on Koinange Street.</p></div></div>';

	$ids   = array_slice( $product->get_upsell_ids(), 0, 3 );
	$items = array_filter( array_map( 'wc_get_product', $ids ), fn( $p ) => $p && $p->is_visible() );
	if ( ! $items ) {
		return;
	}
	$simple = array_filter( $items, fn( $p ) => $p->is_in_stock() && $p->is_type( 'simple' ) );
	echo '<div class="llf-set"><p class="llf-set__title">Frequently bought together</p>';
	foreach ( $items as $p ) {
		printf(
			'<div class="llf-set__item"><a href="%s">%s</a><span><a href="%1$s"><strong>%s</strong></a>%s</span>%s</div>',
			esc_url( $p->get_permalink() ),
			$p->get_image( 'thumbnail' ),
			esc_html( $p->get_name() ),
			$p->get_price_html(),
			$p->is_in_stock() && $p->is_type( 'simple' ) ? '<button type="button" class="llf-set__add" data-llf-add="' . (int) $p->get_id() . '" aria-label="Add ' . esc_attr( $p->get_name() ) . ' to cart">+ Add</button>' : ''
		);
	}
	if ( $product->is_type( 'simple' ) && $product->is_in_stock() && $simple ) {
		$all   = array_merge( [ $product ], $simple );
		$total = array_sum( array_map( fn( $p ) => (float) $p->get_price(), $all ) );
		echo '<button type="button" class="llf-set__all" data-llf-add-many="' . esc_attr( implode( ',', array_map( fn( $p ) => $p->get_id(), $all ) ) ) . '">Add all ' . count( $all ) . ' to cart · KSh ' . esc_html( number_format( $total ) ) . '</button>';
	}
	echo '</div>';
} );

// The upsells already show as "Frequently bought together" next to the button.
add_action( 'init', function () {
	remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );
} );

// How to use, ingredients, authenticity and delivery tabs.
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	global $product;
	if ( ! $product ) {
		return $tabs;
	}
	[ $type, $guide ] = llf_type( $product->get_id() );
	$gear = in_array( $type, LLF_GEAR, true );
	if ( $guide ) {
		$tabs['llf_use'] = [
			'title'    => 'How to use',
			'priority' => 5,
			'callback' => function () use ( $guide, $gear ) {
				$heads = $gear ? [ 'Use it for', 'How', 'Pairs well with' ] : [ 'When to take', 'How much', 'Stack it with' ];
				echo '<table class="llf-spec-table"><tbody>';
				foreach ( $heads as $n => $h ) {
					echo '<tr><th>' . esc_html( $h ) . '</th><td>' . esc_html( $guide[ $n + 1 ] ) . '</td></tr>';
				}
				echo '</tbody></table>';
				if ( ! $gear ) {
					echo '<p class="llf-small">Always follow the dosage on the label. Supplements add to a balanced diet; they don\'t replace it. If you are under 18, pregnant or breastfeeding, on medication or have a medical condition, speak to your doctor before taking supplements.</p>';
				}
			},
		];
	}
	$specs = llf_specs( $product->get_id() );
	$tabs['llf_specs'] = [
		'title'    => $gear ? 'Details' : 'Ingredients & nutrition',
		'priority' => 6,
		'callback' => function () use ( $specs, $gear ) {
			if ( ! $gear ) {
				echo '<p>The full supplement facts, ingredients and allergy information are printed on the label. Swipe through the photos above to read it, or ask us on WhatsApp for a close-up.</p>';
			}
			if ( $specs ) {
				echo '<table class="llf-spec-table"><tbody>';
				foreach ( $specs as $k => $v ) {
					echo '<tr><th>' . esc_html( $k ) . '</th><td>' . esc_html( $v ) . '</td></tr>';
				}
				echo '</tbody></table>';
			}
		},
	];
	if ( ! $gear ) {
		$tabs['llf_authentic'] = [
			'title'    => 'Authenticity',
			'priority' => 30,
			'callback' => function () {
				echo '<ul><li><strong>Sealed and genuine:</strong> every tub, bottle and pack leaves College House sealed, as it came from the brand.</li><li><strong>Check it yourself:</strong> the inner seal should be intact, and the batch number and expiry date printed on the label. Many brands also print a scratch code or QR code you can check on their website.</li><li><strong>See it before you pay:</strong> collect from our shop at College House, Koinange Street, or pay on delivery once you have checked your order.</li><li><strong>Questions?</strong> Send us a photo on WhatsApp ' . esc_html( LLF_PHONE ) . ' and we\'ll walk you through it.</li></ul>';
			},
		];
	}
	$tabs['llf_delivery'] = [
		'title'    => 'Delivery & pickup',
		'priority' => 40,
		'callback' => function () {
			echo '<ul><li><strong>Nairobi CBD pickup:</strong> free at College House, Koinange Street, Monday–Saturday, 9:00 AM – 6:00 PM. We call you when it\'s ready.</li><li><strong>Nairobi doorstep:</strong> same-day rider express, free on orders over KSh ' . number_format( LLF_FREE_DELIVERY ) . '. Pay by M-Pesa or cash on delivery.</li><li><strong>Upcountry:</strong> courier parcel (Fargo or Wells Fargo) to any county, usually 1–2 days. We confirm the courier and charge with you before it leaves.</li><li><strong>Outside Kenya:</strong> WhatsApp us on ' . esc_html( LLF_PHONE ) . ' for a quote.</li></ul>';
		},
	];
	if ( isset( $tabs['description'] ) ) {
		$tabs['description']['priority'] = 1;
	}
	if ( isset( $tabs['reviews'] ) ) {
		$tabs['reviews']['title'] = str_replace( 'Reviews', 'Customer reviews', $tabs['reviews']['title'] );
	}
	unset( $tabs['additional_information'] );
	return $tabs;
}, 20 );

/* -------------------------------------------------------------------------
 * Product cards
 * ---------------------------------------------------------------------- */

function llf_card_product( $instance ) {
	$id = $instance->context['postId'] ?? get_the_ID();
	return $id && ! is_admin() ? wc_get_product( $id ) : null;
}

const LLF_HEART = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 20.3 4.6 13a4.8 4.8 0 0 1 6.8-6.8l.6.6.6-.6a4.8 4.8 0 0 1 6.8 6.8Z"/></svg>';

// Hover image (first gallery photo), size badge, wishlist heart and quick view on product images.
add_filter( 'render_block_woocommerce/product-image', function ( $content, $block, $instance ) {
	$product = llf_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	$gallery = $product->get_gallery_image_ids();
	if ( $gallery ) {
		$alt = wp_get_attachment_image( $gallery[0], 'woocommerce_thumbnail', false, [ 'class' => 'llf-alt-img', 'alt' => '', 'loading' => 'lazy' ] );
		$content = preg_replace( '#(<img[^>]*>)#', '$1' . $alt, $content, 1 );
	}
	$size  = get_post_meta( $product->get_id(), '_llf_spec', true );
	$extra = sprintf(
		'%4$s<button type="button" class="llf-heart" data-llf-wish="%1$d" aria-label="Save %2$s to wishlist" aria-pressed="false">%3$s</button><button type="button" class="llf-qv-btn" data-llf-qv="%1$d" aria-label="Quick view of %2$s">Quick view</button>',
		$product->get_id(),
		esc_attr( $product->get_name() ),
		LLF_HEART,
		$size ? '<span class="llf-size">' . esc_html( $size ) . '</span>' : ''
	);
	$pos = strrpos( $content, '</div>' );
	return $pos === false ? $content : substr_replace( $content, $extra . '</div>', $pos, 6 );
}, 10, 3 );

// Products with options show their lowest price, not a range.
add_filter( 'woocommerce_variable_price_html', function ( $html, $product ) {
	$min = $product->get_variation_price( 'min', true );
	return $min === $product->get_variation_price( 'max', true ) ? $html : '<span class="llf-from">From</span> ' . wc_price( $min );
}, 10, 2 );

// Goal badge, made-to-order and stock above the price.
add_filter( 'render_block_woocommerce/product-price', function ( $content, $block, $instance ) {
	$product = llf_card_product( $instance );
	// Product cards only; the product page shows all its goals above the button.
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	$before = '';
	$goals  = llf_product_goals( $product->get_id() );
	if ( $goals ) {
		$before .= '<span class="llf-badge llf-badge--goal">' . esc_html( $goals[0]->name ) . '</span>';
	}
	if ( get_post_meta( $product->get_id(), '_llf_made_to_order', true ) === 'yes' ) {
		$before .= '<span class="llf-badge">Made to order</span>';
	} elseif ( ! $product->is_in_stock() ) {
		$before .= '<span class="llf-badge llf-badge--out">Out of stock</span>';
	} elseif ( $product->managing_stock() && (int) $product->get_stock_quantity() <= LLF_LOW_STOCK ) {
		$before .= '<span class="llf-badge llf-badge--low">Only ' . (int) $product->get_stock_quantity() . ' left</span>';
	}
	return ( $before ? '<div class="llf-badges">' . $before . '</div>' : '' ) . $content;
}, 10, 3 );

// Sale badge shows the saving, e.g. "−18%".
add_filter( 'render_block_woocommerce/product-sale-badge', function ( $content, $block, $instance ) {
	$product = llf_card_product( $instance );
	if ( ! $product || ! $product->is_on_sale() || ! $product->is_type( 'simple' ) ) {
		return $content;
	}
	$reg  = (float) $product->get_regular_price();
	$sale = (float) $product->get_sale_price();
	$pct  = $reg > 0 && $sale > 0 ? round( ( $reg - $sale ) / $reg * 100 ) : 0;
	return $pct ? preg_replace( '#>\s*Sale\s*<#', '>−' . $pct . '%<', $content, 1 ) : $content;
}, 10, 3 );

/* -------------------------------------------------------------------------
 * Home page and shop sections
 * ---------------------------------------------------------------------- */

function llf_categories() {
	$terms = get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => true, 'exclude' => [ (int) get_option( 'default_product_cat' ) ], 'orderby' => 'meta_value_num', 'meta_key' => 'order' ] );
	return is_wp_error( $terms ) ? [] : $terms;
}

function llf_goals() {
	$tax = wc_attribute_taxonomy_name( 'goal' );
	if ( ! taxonomy_exists( $tax ) ) {
		return [];
	}
	$terms = get_terms( [ 'taxonomy' => $tax, 'hide_empty' => true, 'orderby' => 'meta_value_num', 'meta_key' => 'order' ] );
	return is_wp_error( $terms ) ? [] : $terms;
}

// "Shop by category": one tile per category, shown with a photo of its first product.
add_shortcode( 'llf_needs', function () {
	$h = '<div class="llf-needs">';
	foreach ( llf_categories() as $t ) {
		$first = wc_get_products( [ 'category' => [ $t->slug ], 'limit' => 1, 'orderby' => 'menu_order', 'order' => 'ASC', 'status' => 'publish' ] );
		$img   = $first ? $first[0]->get_image( 'woocommerce_thumbnail', [ 'loading' => 'lazy', 'alt' => '' ] ) : '';
		$h .= sprintf(
			'<a class="llf-need" href="%s"><span class="llf-need__img">%s</span><span class="llf-need__txt"><strong>%s</strong><em>%s</em></span></a>',
			esc_url( get_term_link( $t ) ),
			$img,
			esc_html( $t->name ),
			esc_html( sprintf( _n( '%d product', '%d products', $t->count ), $t->count ) )
		);
	}
	return $h . '</div>';
} );

// "Shop by training goal": what each goal covers, shown with a product to start with.
const LLF_GOAL_COPY = [
	'muscle-gain'  => [ '💪', 'Whey, gainers & creatine', 'rule-1-whey-protein' ],
	'fat-loss'     => [ '🔥', 'Lean whey, burners & L-carnitine', 'nutrex-lipo-6-black-ultra-concentrate' ],
	'strength'     => [ '⚡', 'Pre-workouts, nitric oxide & lifting gear', 'cellucor-c4-original' ],
	'endurance'    => [ '🏃', 'Amino energy, beta-alanine & electrolytes', 'optimum-nutrition-amino-energy' ],
	'recovery'     => [ '💧', 'EAAs, aminos, casein & hydration', 'mutant-geaar-eaa' ],
	'wellness'     => [ '🌿', 'Multivitamins, D3, fish oil & ZMB', 'animal-pak' ],
	'calisthenics' => [ '🤸', 'Parallettes, dip bars, gloves & bottles', 'metal-high-bar-parallettes' ],
];
add_shortcode( 'llf_goals', function () {
	$h = '<div class="llf-goals">';
	foreach ( llf_goals() as $t ) {
		[ $icon, $line, $slug ] = LLF_GOAL_COPY[ $t->slug ] ?? [ '•', '', '' ];
		$p   = $slug ? get_page_by_path( $slug, OBJECT, 'product' ) : null;
		$img = $p ? get_the_post_thumbnail( $p->ID, 'woocommerce_thumbnail', [ 'loading' => 'lazy', 'alt' => '' ] ) : '';
		$h  .= sprintf(
			'<a class="llf-goal" href="%s"><span class="llf-goal__img">%s</span><span class="llf-goal__txt"><span class="llf-goal__icon" aria-hidden="true">%s</span><strong>%s</strong><em>%s</em><small>%d products →</small></span></a>',
			esc_url( add_query_arg( 'filter_goal', $t->slug, wc_get_page_permalink( 'shop' ) ) ),
			$img,
			$icon,
			esc_html( $t->name ),
			esc_html( $line ),
			(int) $t->count
		);
	}
	return $h . '</div>';
} );

// Budget quick filter and in-stock switch.
add_shortcode( 'llf_budget', function () {
	$shop = wc_get_page_permalink( 'shop' );
	$h    = '<div class="llf-budget"><span class="llf-budget__label">Shop by budget</span>';
	foreach ( LLF_BUDGETS as [ $label, $min, $max ] ) {
		$h .= '<a class="llf-chip" href="' . esc_url( add_query_arg( array_filter( [ 'min_price' => $min, 'max_price' => $max ] ), $shop ) ) . '">' . esc_html( $label ) . '</a>';
	}
	return $h . '<a class="llf-chip llf-chip--ghost" href="' . esc_url( add_query_arg( 'instock', '1', $shop ) ) . '">✓ In stock now</a><a class="llf-chip llf-chip--accent" href="' . esc_url( home_url( '/stack-builder/' ) ) . '">Build my stack →</a></div>';
} );

// A row of product cards from one category, e.g. [llf_collection cat="creatine-pre" limit="10"].
// Built as a Product Collection block at render time, because the block needs the category's term id.
add_shortcode( 'llf_collection', function ( $atts ) {
	$atts = shortcode_atts( [ 'cat' => '', 'limit' => 10, 'columns' => 5 ], $atts );
	$term = get_term_by( 'slug', $atts['cat'], 'product_cat' );
	if ( ! $term ) {
		return '';
	}
	static $qid = 40;
	$query = [
		'perPage' => (int) $atts['limit'], 'pages' => 1, 'offset' => 0, 'postType' => 'product', 'order' => 'asc', 'orderBy' => 'menu_order',
		'search' => '', 'exclude' => [], 'inherit' => false, 'taxQuery' => [ 'product_cat' => [ $term->term_id ] ], 'isProductCollectionBlock' => true,
		'featured' => false, 'woocommerceOnSale' => false, 'woocommerceStockStatus' => [ 'instock', 'outofstock', 'onbackorder' ], 'woocommerceAttributes' => [], 'woocommerceHandPickedProducts' => [],
	];
	$attrs = [ 'queryId' => $qid++, 'query' => $query, 'tagName' => 'div', 'displayLayout' => [ 'type' => 'flex', 'columns' => (int) $atts['columns'], 'shrinkColumns' => true ], 'dimensions' => [ 'widthType' => 'fill' ], 'queryContextIncludes' => [ 'collection' ] ];
	return do_blocks( '<!-- wp:woocommerce/product-collection ' . wp_json_encode( $attrs ) . ' --><div class="wp-block-woocommerce-product-collection">' . LLF_CARD . '</div><!-- /wp:woocommerce/product-collection -->' );
} );

// The product card used by every product grid.
const LLF_CARD = '<!-- wp:woocommerce/product-template -->
<!-- wp:woocommerce/product-image {"showSaleBadge":false,"isDescendentOfQueryLoop":true,"aspectRatio":"4/5","scale":"cover"} -->
<!-- wp:woocommerce/product-sale-badge {"isDescendentOfQueryLoop":true,"align":"right"} /-->
<!-- /wp:woocommerce/product-image -->
<!-- wp:post-title {"level":3,"isLink":true,"style":{"spacing":{"margin":{"bottom":"0.2rem","top":"0.7rem"}},"typography":{"fontSize":"0.95rem","lineHeight":"1.3","fontWeight":"600"}},"__woocommerceNamespace":"woocommerce/product-collection/product-title"} /-->
<!-- wp:woocommerce/product-price {"isDescendentOfQueryLoop":true,"fontSize":"medium"} /-->
<!-- wp:woocommerce/product-button {"isDescendentOfQueryLoop":true,"fontSize":"small"} /-->
<!-- /wp:woocommerce/product-template -->';

// Brands, the ones with the most products first.
function llf_brands( $limit = 0 ) {
	if ( ! taxonomy_exists( 'product_brand' ) ) {
		return [];
	}
	$terms = get_terms( [ 'taxonomy' => 'product_brand', 'hide_empty' => true, 'orderby' => 'count', 'order' => 'DESC', 'number' => $limit ] );
	return is_wp_error( $terms ) ? [] : $terms;
}

add_shortcode( 'llf_brands', function () {
	$brands = llf_brands( 12 );
	if ( ! $brands ) {
		return '';
	}
	$h = '<div class="llf-brands"><p class="llf-brands__label">Top brands</p><div class="llf-brands__list">';
	foreach ( $brands as $t ) {
		$h .= '<a href="' . esc_url( get_term_link( $t ) ) . '">' . esc_html( $t->name ) . '</a>';
	}
	return $h . '<a href="' . esc_url( wc_get_page_permalink( 'shop' ) ) . '" class="llf-brands__all">All ' . count( llf_brands() ) . ' brands →</a></div></div>';
} );

// Real Google reviews (5.0 from 73 reviews when this was built). Staff can add more here.
const LLF_REVIEWS = [
	[ 'Charles C.', 'How they took time to explain every question I had about building muscle while losing fat and which supplements to use according to my budget.' ],
	[ 'George K.', 'Fast response and also offer advise on how to use the product effectively for my gym strength. Would highly recommend!' ],
	[ 'John', 'The Best Customer Service I\'ve experienced so far. Delivered in time and right at my doorstep.' ],
	[ 'Jeff N.', 'Excellent customer service, genuine, high-quality products, and timely delivery. 100% recommend.' ],
	[ 'Amira A.', 'A customer from Uganda, this was a very good experience with this company… they don\'t only sell products but also explain on how to use and its benefits.' ],
	[ 'Precious K.', 'Wonderful team and excellent customer service! I picked up their creatine for women and couldn\'t be happier, you can tell they really know their stuff.' ],
];
add_shortcode( 'llf_reviews', function () {
	$h = '<div class="llf-reviews" data-llf-carousel><div class="llf-reviews__track">';
	foreach ( LLF_REVIEWS as [ $name, $text ] ) {
		$h .= '<figure class="llf-review"><div class="llf-stars" aria-label="5 out of 5 stars">★★★★★</div><blockquote>“' . esc_html( $text ) . '”</blockquote><figcaption><span>' . esc_html( mb_substr( $name, 0, 1 ) ) . '</span>' . esc_html( $name ) . '<em>Google review</em></figcaption></figure>';
	}
	return $h . '</div><div class="llf-reviews__nav"><button type="button" data-llf-prev aria-label="Previous reviews">←</button><button type="button" data-llf-next aria-label="Next reviews">→</button></div></div>';
} );

// The page being filtered, and the filter choices already in its address.
function llf_filter_state() {
	$current = get_queried_object();
	$base    = $current instanceof WP_Term ? get_term_link( $current ) : wc_get_page_permalink( 'shop' );
	$keep    = [];
	foreach ( array_merge( [ 'min_price', 'max_price', 'instock', 'orderby', 's', 'post_type' ], array_map( fn( $k ) => "filter_$k", array_keys( LLF_FILTERS ) ) ) as $key ) {
		if ( isset( $_GET[ $key ] ) && $_GET[ $key ] !== '' ) {
			$keep[ $key ] = sanitize_text_field( wp_unslash( $_GET[ $key ] ) );
		}
	}
	return [ $current, is_wp_error( $base ) ? wc_get_page_permalink( 'shop' ) : $base, $keep ];
}

// Category, goal and budget chips, then brands, price and stock, above shop, category, brand and search results.
add_shortcode( 'llf_filters', function () {
	global $wpdb;
	[ $current, $base, $keep ] = llf_filter_state();
	$cur_id = $current instanceof WP_Term ? $current->term_id : 0;
	$link   = fn( $args ) => esc_url( add_query_arg( $args, $base ) );

	$h = '<nav class="llf-filters" aria-label="Filter products"><div class="llf-filters__row">';
	$h .= '<a class="llf-chip' . ( is_shop() && ! is_search() ? ' is-on' : '' ) . '" href="' . esc_url( wc_get_page_permalink( 'shop' ) ) . '">All</a>';
	foreach ( llf_categories() as $t ) {
		$h .= sprintf( '<a class="llf-chip%s" href="%s">%s <em>%d</em></a>', $t->term_id === $cur_id ? ' is-on' : '', esc_url( get_term_link( $t ) ), esc_html( $t->name ), (int) $t->count );
	}
	$h .= '</div>';

	// Training goals.
	$chosen = $keep['filter_goal'] ?? '';
	$h     .= '<div class="llf-filters__row llf-filters__row--goals"><span class="llf-refine__label">Goal</span>';
	foreach ( llf_goals() as $t ) {
		$on   = $chosen === $t->slug;
		$args = $on ? array_diff_key( $keep, [ 'filter_goal' => 1 ] ) : array_merge( $keep, [ 'filter_goal' => $t->slug ] );
		$h   .= sprintf( '<a class="llf-chip llf-chip--sm%s" href="%s" rel="nofollow">%s</a>', $on ? ' is-on' : '', $link( $args ), esc_html( $t->name ) );
	}
	$h .= '</div>';

	// Budget, plus the in-stock switch.
	$h .= '<div class="llf-filters__row"><span class="llf-refine__label">Budget</span>';
	foreach ( LLF_BUDGETS as [ $label, $min, $max ] ) {
		$on   = ( isset( $keep['min_price'] ) || isset( $keep['max_price'] ) ) && (int) ( $keep['min_price'] ?? 0 ) === $min && (int) ( $keep['max_price'] ?? 0 ) === $max;
		$args = array_diff_key( $keep, [ 'min_price' => 1, 'max_price' => 1 ] );
		if ( ! $on ) {
			$args = array_merge( $args, array_filter( [ 'min_price' => $min, 'max_price' => $max ] ) );
		}
		$h .= sprintf( '<a class="llf-chip llf-chip--sm%s" href="%s" rel="nofollow">%s</a>', $on ? ' is-on' : '', $link( $args ), esc_html( $label ) );
	}
	$stock_on = ! empty( $keep['instock'] );
	$h       .= sprintf( '<a class="llf-switch%s" href="%s" rel="nofollow" role="switch" aria-checked="%s"><span></span>In stock only</a>', $stock_on ? ' is-on' : '', $link( $stock_on ? array_diff_key( $keep, [ 'instock' => 1 ] ) : array_merge( $keep, [ 'instock' => '1' ] ) ), $stock_on ? 'true' : 'false' );
	$h       .= '</div>';

	// Products on this page before any filter, to offer only the prices and brands that exist here.
	$args = [ 'post_type' => 'product', 'post_status' => 'publish', 'fields' => 'ids', 'posts_per_page' => 500, 'no_found_rows' => true ];
	if ( $current instanceof WP_Term ) {
		$args['tax_query'] = [ [ 'taxonomy' => $current->taxonomy, 'terms' => [ $current->term_id ] ] ];
	}
	$ids    = get_posts( $args );
	$active = count( array_diff_key( $keep, array_flip( [ 'orderby', 's', 'post_type' ] ) ) );
	if ( count( $ids ) > 1 ) {
		$in  = implode( ',', array_map( 'intval', $ids ) );
		$top = (float) $wpdb->get_var( "SELECT MAX(max_price) FROM {$wpdb->wc_product_meta_lookup} WHERE product_id IN ($in)" );
		$top = (int) ( ceil( $top / 1000 ) * 1000 );
		$min = min( $top, max( 0, (int) ( $keep['min_price'] ?? 0 ) ) );
		$max = min( $top, (int) ( $keep['max_price'] ?? $top ) ) ?: $top;

		$h .= '<details class="llf-refine"><summary>More filters: price slider &amp; brand</summary><div class="llf-refine__body">';
		$h .= '<form class="llf-price" method="get" action="' . esc_url( $base ) . '" data-llf-price>';
		foreach ( array_diff_key( $keep, array_flip( [ 'min_price', 'max_price' ] ) ) as $k => $v ) {
			$h .= '<input type="hidden" name="' . esc_attr( $k ) . '" value="' . esc_attr( $v ) . '">';
		}
		$h .= sprintf(
			'<span class="llf-refine__label">Price</span><div class="llf-price__sliders"><input type="range" name="min_price" min="0" max="%1$d" step="500" value="%2$d" aria-label="Lowest price"><input type="range" name="max_price" min="0" max="%1$d" step="500" value="%3$d" aria-label="Highest price"></div><output>KSh %4$s – KSh %5$s</output><button class="llf-chip llf-chip--sm is-on" type="submit">Apply</button></form>',
			$top, $min, $max, number_format( $min ), number_format( $max )
		);
		$brands = taxonomy_exists( 'product_brand' ) ? wp_get_object_terms( $ids, 'product_brand', [ 'orderby' => 'name' ] ) : [];
		if ( ! is_wp_error( $brands ) && count( $brands ) > 1 ) {
			$h .= '<div class="llf-filters__row"><span class="llf-refine__label">Brand</span>';
			foreach ( $brands as $t ) {
				$h .= sprintf( '<a class="llf-chip llf-chip--sm%s" href="%s">%s</a>', $t->term_id === $cur_id ? ' is-on' : '', esc_url( get_term_link( $t ) ), esc_html( $t->name ) );
			}
			$h .= '</div>';
		}
		$h .= '</div></details>';
	}
	if ( $active ) {
		$h .= '<a class="llf-refine__clear" href="' . esc_url( add_query_arg( array_intersect_key( $keep, array_flip( [ 'orderby', 's', 'post_type' ] ) ), $base ) ) . '">✕ Clear filters</a>';
	}
	return $h . '</nav>';
} );

// "In stock only" switch on shop pages.
add_action( 'woocommerce_product_query', function ( $q ) {
	if ( ! empty( $_GET['instock'] ) ) {
		$meta   = (array) $q->get( 'meta_query' );
		$meta[] = [ 'key' => '_stock_status', 'value' => 'instock' ];
		$q->set( 'meta_query', $meta );
	}
} );
add_filter( 'query_loop_block_query_vars', function ( $vars ) {
	if ( ! empty( $_GET['instock'] ) && ( $vars['post_type'] ?? '' ) === 'product' ) {
		$vars['meta_query']   = (array) ( $vars['meta_query'] ?? [] );
		$vars['meta_query'][] = [ 'key' => '_stock_status', 'value' => 'instock' ];
	}
	return $vars;
} );

add_shortcode( 'llf_wishlist', function () {
	return '<div class="llf-wishlist" data-llf-wishlist><p class="llf-small">Loading your saved items…</p></div>';
} );

/* -------------------------------------------------------------------------
 * Stack builder
 * ---------------------------------------------------------------------- */

// The wizard runs in llf.js; this hands it the in-stock products it can recommend.
add_shortcode( 'llf_stack_builder', function () {
	$items = [];
	foreach ( wc_get_products( [ 'status' => 'publish', 'limit' => -1, 'type' => 'simple', 'stock_status' => 'instock' ] ) as $p ) {
		[ $type ] = llf_type( $p->get_id() );
		if ( ! $type ) {
			continue;
		}
		$img     = wp_get_attachment_image_url( $p->get_image_id(), 'woocommerce_thumbnail' );
		$items[] = [ 'id' => $p->get_id(), 'name' => $p->get_name(), 'price' => (float) $p->get_price(), 'type' => $type, 'size' => (string) get_post_meta( $p->get_id(), '_llf_spec', true ), 'img' => $img ?: '', 'url' => $p->get_permalink() ];
	}
	$guides = array_map( fn( $g ) => [ 'label' => $g[0], 'when' => $g[1] ], llf_types() );
	return '<div class="llf-stack" data-llf-stack>'
		. '<script type="application/json" data-llf-stack-data>' . wp_json_encode( [ 'products' => $items, 'guides' => $guides ] ) . '</script>'
		. '<ol class="llf-stack__steps" aria-label="Steps"><li class="is-on">Goal</li><li>Experience</li><li>Budget</li><li>Your stack</li></ol>'
		. '<section data-step="1"><h2>What\'s your main goal?</h2><div class="llf-stack__options">'
		. '<button type="button" data-goal="muscle"><span>💪</span><strong>Build muscle</strong><em>Size and strength, eat more</em></button>'
		. '<button type="button" data-goal="fatloss"><span>🔥</span><strong>Lose fat</strong><em>Get lean and keep your muscle</em></button>'
		. '<button type="button" data-goal="strength"><span>⚡</span><strong>Increase strength</strong><em>Lift heavier, train harder</em></button>'
		. '<button type="button" data-goal="endurance"><span>🏃</span><strong>Endurance &amp; energy</strong><em>Running, sport, long sessions</em></button>'
		. '</div></section>'
		. '<section data-step="2" hidden><h2>How long have you been training?</h2><div class="llf-stack__options">'
		. '<button type="button" data-level="beginner"><span>🌱</span><strong>Beginner</strong><em>Under 6 months</em></button>'
		. '<button type="button" data-level="intermediate"><span>🏋️</span><strong>Intermediate</strong><em>6 months to 2 years</em></button>'
		. '<button type="button" data-level="advanced"><span>🦁</span><strong>Advanced</strong><em>2 years or more</em></button>'
		. '</div><button type="button" class="llf-link" data-back>← Back</button></section>'
		. '<section data-step="3" hidden><h2>What\'s your budget?</h2><div class="llf-stack__options llf-stack__options--budget">'
		. '<button type="button" data-budget="5000"><strong>KSh 5,000</strong></button><button type="button" data-budget="10000"><strong>KSh 10,000</strong></button><button type="button" data-budget="15000"><strong>KSh 15,000</strong></button><button type="button" data-budget="25000"><strong>KSh 25,000</strong></button>'
		. '</div><form class="llf-stack__own" data-own-budget><label for="llf-budget">Or type your own budget (KSh)</label><div><input id="llf-budget" type="number" min="1000" step="500" inputmode="numeric" placeholder="e.g. 8000" required><button class="wp-element-button" type="submit">Build my stack</button></div></form>'
		. '<button type="button" class="llf-link" data-back>← Back</button></section>'
		. '<section data-step="4" hidden><div data-llf-stack-result></div></section>'
		. '</div>';
} );

/* -------------------------------------------------------------------------
 * Quick view, cart, checkout, order confirmation
 * ---------------------------------------------------------------------- */

// Quick view pop-up, filled in by llf.js.
add_action( 'wp_footer', function () {
	echo '<dialog id="llf-qv" class="llf-dialog llf-qv" aria-label="Quick view"><form method="dialog"><button class="llf-dialog__close" aria-label="Close">×</button></form><div data-llf-qv-body></div></dialog>';
} );

function llf_freebar_html() {
	$total = WC()->cart ? (float) WC()->cart->get_displayed_subtotal() : 0;
	$left  = max( 0, LLF_FREE_DELIVERY - $total );
	$pct   = min( 100, round( $total / LLF_FREE_DELIVERY * 100 ) );
	$msg   = $left > 0
		? 'Add <strong>KSh ' . number_format( $left ) . '</strong> more for <strong>free Nairobi doorstep delivery</strong>'
		: '<strong>You\'ve unlocked free Nairobi doorstep delivery!</strong>';
	return '<div class="llf-freebar" data-llf-freebar>' . $msg . '<div class="llf-freebar__track"><div class="llf-freebar__fill" style="width:' . $pct . '%"></div></div></div>';
}
function llf_wa_cart_html() {
	return '<button type="button" class="llf-wa-cart" data-llf-wa-cart>' . LLF_WA_ICON . 'Send this cart to us on WhatsApp</button>';
}
add_filter( 'render_block_woocommerce/cart', fn( $c ) => llf_freebar_html() . $c );
add_filter( 'render_block_woocommerce/proceed-to-checkout-block', fn( $c ) => $c . llf_wa_cart_html() );
add_filter( 'render_block_woocommerce/mini-cart-contents', function ( $c ) {
	return preg_replace( '#(<div[^>]*wp-block-woocommerce-filled-mini-cart-contents-block[^>]*>)#', '$1' . llf_freebar_html(), $c, 1 );
} );
add_filter( 'render_block_woocommerce/mini-cart-footer-block', fn( $c ) => $c . '<div class="llf-wa-cart-wrap">' . llf_wa_cart_html() . '</div>' );

// A landmark helps riders find the customer.
add_action( 'woocommerce_init', function () {
	if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
		return;
	}
	woocommerce_register_additional_checkout_field( [
		'id'       => 'llf/landmark',
		'label'    => 'Building or nearest landmark',
		'location' => 'address',
		'type'     => 'text',
		'required' => false,
	] );
} );

// Tracking code, estimated delivery and WhatsApp receipt on the order confirmation page.
function llf_tracking_code( WC_Order $order ) {
	return 'LLF-' . $order->get_order_number() . '-' . strtoupper( substr( $order->get_order_key(), -4 ) );
}
function llf_eta( WC_Order $order ) {
	$method = strtolower( $order->get_shipping_method() );
	if ( str_contains( $method, 'pick' ) ) {
		return 'Ready to collect at College House, Koinange Street. We\'ll call you when it\'s packed (Monday–Saturday, 9 AM – 6 PM).';
	}
	if ( str_contains( $method, 'upcountry' ) || str_contains( $method, 'courier' ) ) {
		return 'Upcountry courier: usually 1–2 days. We\'ll confirm the courier and send you the parcel details.';
	}
	return 'Nairobi doorstep: same-day rider express. We\'ll call you before the rider leaves.';
}
function llf_whatsapp_order_link( WC_Order $order ) {
	$lines = [ 'Hi Lionlegacy Fitness, I just placed order ' . llf_tracking_code( $order ) . ':' ];
	foreach ( $order->get_items() as $item ) {
		$lines[] = '• ' . $item->get_quantity() . ' × ' . $item->get_name() . ' – KSh ' . number_format( (float) $item->get_total() );
	}
	$lines[] = 'Total: KSh ' . number_format( (float) $order->get_total() );
	$lines[] = 'Delivery: ' . $order->get_shipping_method();
	$address = trim( implode( ', ', array_filter( [ $order->get_shipping_address_1(), $order->get_shipping_city() ] ) ) );
	if ( $address ) {
		$lines[] = 'Deliver to: ' . $address;
	}
	$lines[] = 'Payment: ' . $order->get_payment_method_title();
	$lines[] = 'Name: ' . $order->get_formatted_billing_full_name() . ', ' . $order->get_billing_phone();
	return llf_wa_link( implode( "\n", $lines ) );
}
add_filter( 'render_block_woocommerce/order-confirmation-status', function ( $content ) {
	$order_id = absint( get_query_var( 'order-received' ) );
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	if ( ! $order || ! hash_equals( $order->get_order_key(), wc_clean( wp_unslash( $_GET['key'] ?? '' ) ) ) ) {
		return $content;
	}
	return $content . '<div class="llf-thanks"><p class="llf-thanks__code">Order tracking number <strong>' . esc_html( llf_tracking_code( $order ) ) . '</strong></p><p class="llf-thanks__eta">' . esc_html( llf_eta( $order ) ) . '</p><p>We\'ll call you shortly to confirm. To speed things up, send the order to us on WhatsApp.</p><a class="wp-element-button llf-wa-btn" href="' . esc_attr( llf_whatsapp_order_link( $order ) ) . '" target="_blank" rel="noopener">' . LLF_WA_ICON . 'Send order to WhatsApp (' . esc_html( LLF_PHONE ) . ')</a></div>';
} );
add_action( 'woocommerce_admin_order_data_after_order_details', function ( $order ) {
	echo '<p class="form-field form-field-wide"><strong>Tracking number:</strong> ' . esc_html( llf_tracking_code( $order ) ) . '</p>';
} );

// Staff edit the size badge, details, usage guide and made-to-order flag on the product screen.
add_action( 'woocommerce_product_options_general_product_data', function () {
	woocommerce_wp_text_input( [ 'id' => '_llf_spec', 'label' => 'Size badge', 'description' => 'Shown on the product photo, e.g. "2.28 kg · 65 servings".', 'desc_tip' => true ] );
	woocommerce_wp_select( [ 'id' => '_llf_type', 'label' => 'Usage guide', 'description' => 'Picks the "How to use" advice and where the stack builder suggests it.', 'desc_tip' => true, 'options' => [ '' => '— None —' ] + array_map( fn( $g ) => $g[0], llf_types() ) ] );
	woocommerce_wp_textarea_input( [ 'id' => '_llf_specs', 'label' => 'Details', 'rows' => 5, 'description' => 'One per line, as "Label: value", e.g. "Size: 2.28 kg". The first four also show next to the price.' ] );
	woocommerce_wp_checkbox( [ 'id' => '_llf_made_to_order', 'label' => 'Made to order', 'description' => 'Shows the "Made to order" badge and lead time instead of stock.' ] );
} );
add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	foreach ( [ '_llf_spec' => 'sanitize_text_field', '_llf_type' => 'sanitize_key', '_llf_specs' => 'sanitize_textarea_field' ] as $key => $clean ) {
		if ( isset( $_POST[ $key ] ) ) {
			$product->update_meta_data( $key, $clean( wp_unslash( $_POST[ $key ] ) ) );
		}
	}
	$product->update_meta_data( '_llf_made_to_order', isset( $_POST['_llf_made_to_order'] ) ? 'yes' : 'no' );
} );

/* -------------------------------------------------------------------------
 * Housekeeping
 * ---------------------------------------------------------------------- */

// Kenyan addresses: no postcode, and riders need a phone number.
add_filter( 'woocommerce_get_country_locale', function ( $locale ) {
	$locale['KE']['postcode'] = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['city']     = [ 'label' => 'Area / Estate / Town (e.g. CBD, Westlands, Nakuru)' ];
	$locale['KE']['phone']    = [ 'required' => true ];
	return $locale;
} );

// Demo stores ship web-sized photos and skip thumbnails (see setup.php).
if ( get_option( 'llf_fast_images' ) === 'yes' ) {
	add_filter( 'woocommerce_resize_images', '__return_false' );
	add_filter( 'woocommerce_background_image_regeneration', '__return_false' );
}

// Shop thumbnails match the 4:5 product cards (WooCommerce's default is a 300px square).
add_filter( 'woocommerce_get_image_size_thumbnail', function () {
	return [ 'width' => 480, 'height' => 600, 'crop' => 1 ];
} );

// Local preview only: the SQLite layer can't run WooCommerce's stock-reservation query.
// Real hosting uses MySQL, where this never triggers.
if ( isset( $GLOBALS['wpdb'] ) && stripos( get_class( $GLOBALS['wpdb'] ), 'sqlite' ) !== false ) {
	add_filter( 'woocommerce_hold_stock_for_checkout', '__return_false' );
}

// Browser tab icon.
add_action( 'wp_head', function () {
	if ( has_site_icon() ) {
		return;
	}
	$src = esc_url( get_stylesheet_directory_uri() . '/assets/icon.png' );
	echo "<link rel=\"icon\" href=\"$src\">\n<link rel=\"apple-touch-icon\" href=\"$src\">\n<meta name=\"theme-color\" content=\"#0F0F0F\">\n";
} );

// Templates use root-relative links ("/shop/"); point them at the real home URL so the site
// also works from a sub-folder (e.g. the WordPress Playground demo).
add_filter( 'render_block', function ( $content ) {
	$home = trailingslashit( home_url() );
	if ( $home === '/' || ! str_contains( $content, '="/' ) ) {
		return $content;
	}
	return preg_replace( '#\b(href|src)="/(?!/)#', '$1="' . $home, $content );
} );

// The shop shows no WordPress toolbar, version tags or discovery links. Staff work from /wp-admin.
add_filter( 'show_admin_bar', '__return_false' );
add_filter( 'the_generator', '__return_empty_string' );
add_filter( 'xmlrpc_enabled', '__return_false' );
add_filter( 'emoji_svg_url', '__return_false' );
add_filter( 'wp_headers', function ( $headers ) {
	unset( $headers['X-Pingback'] );
	return $headers;
} );
add_action( 'init', function () {
	remove_action( 'wp_head', 'wp_generator' );
	remove_action( 'wp_head', 'rsd_link' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
	remove_action( 'wp_head', 'wp_shortlink_wp_head' );
	remove_action( 'wp_head', 'rest_output_link_wp_head' );
	remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
	remove_action( 'wp_head', 'feed_links', 2 );
	remove_action( 'wp_head', 'feed_links_extra', 3 );
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_footer_scripts', 'print_emoji_detection_script' );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_enqueue_scripts', 'wp_enqueue_emoji_styles' );
	remove_action( 'template_redirect', 'rest_output_link_header', 11 );
	remove_action( 'template_redirect', 'wp_shortlink_header', 11 );
} );

// The staff login page carries the shop's logo instead of the WordPress one.
add_action( 'login_enqueue_scripts', function () {
	$logo = esc_url( get_stylesheet_directory_uri() . '/assets/logo.webp' );
	echo "<style>body.login{background:#0F0F0F}body.login #login h1 a{background:url($logo) center/contain no-repeat;width:140px;height:132px}body.login #nav a{color:#E2E8F0}#backtoblog,.language-switcher{display:none}</style>";
} );
add_filter( 'login_title', fn( $title ) => str_replace( [ ' &#8212; WordPress', ' — WordPress' ], '', $title ) );
add_filter( 'login_headerurl', fn() => home_url( '/' ) );
add_filter( 'login_headertext', fn() => 'Lionlegacy Fitness' );
